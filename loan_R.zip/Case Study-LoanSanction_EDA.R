

####################################################################
# Setting working directory, Loading Libraries, and data
####################################################################

rm(list=ls())

setwd("C:/Users/rbose/Documents/Rajat/Study/Post Course/Assignment/Group Case Study 2")


library(tidyr)
library(dplyr)
library(stringr)
library(lubridate)
library(ggplot2)
library(stargazer)
library(reshape)
#library(ggthemes)
#library(lattice)
#library(plotly)
# library(RColorBrewer)
# library(maps)



# loan dataset
loan<- read.csv("loan.csv",header = TRUE, sep=",")


############################# Overview of Dataset ########################################

# Glimpse of all variables

# display the column names
as.data.frame(names(loan))


# This dataset contains 39717 loans with 111 variables on each loan
str(loan)
summary(loan)

# We see that there are several variables that need our attention:

#  id, member_id, loan_amnt, funded_amnt and few more columns are loaded as integer. as interger is subset of numeric we can convert it to numeric
#  funded_amnt_inv, installment,annual_inc,dti,total_pymnt and other columns  seems to be correctly loaded as numeric
#  int_rate is read as factor because of "%" sign in the value.we need to drop the % and define the rate as a numeric
#  grade, sub_grade, emp_length (the length of employment),home_ownership seems to be correctly loaded as categorical


# Count unique values in all the columns
as.data.frame(rapply(loan,function(x)length(unique(x))))


# Output the stats about the attributes in text file 
stargazer(loan, type = "text", title="Descriptive statistics", digits=1, out="loan_stats.txt")



############################ Data Pre-Processing ##########################

############################ Cleaning, modifying and adding columns to original data #################################

# Check duplicate rows 
x<-loan[duplicated(loan), ]
dim(x)

# Check for duplicate values in id column
sum(duplicated(loan$id))                                # no duplicate values

# Check count of Duplicated Records
nrow(loan) - nrow(unique(loan))                         # since no duplicate values hence count is 0


# Cross check - if there are no duplicate rows then row count from below commend should match
dim(loan)
loan_dup_excluded<-loan[!duplicated(loan), ]
dim (loan_dup_excluded)


# Check for NA values (missing values) in fields those will be used for analysis 
sum(is.na(loan$id))                         # no missing values
sum(is.na(loan$member_id))                  # no missing values
sum(is.na(loan$annual_inc))                 # no missing values
sum(is.na(loan$term))                       # no missing values
sum(is.na(loan$emp_length))                 # no missing values
sum(is.na(loan$home_ownership))             # no missing values
sum(is.na(loan$verification_status))        # no missing values
sum(is.na(loan$loan_status))                # no missing values
sum(is.na(loan$purpose))                    # no missing values
sum(is.na(loan$earl_cr_line))               # no missing values
sum(is.na(loan$issue_d))                    # no missing values
sum(is.na(loan$delinq_2yrs))                # no missing values
sum(is.na(loan$inq_last_6mths))             # no missing values



######### Exclude columns that are entirely NA values, it will leave columns where only some values are NA
loan_1 <- loan[ , ! apply( loan , 2 , function(x) all(is.na(x)) ) ]
str(loan_1)
dim(loan_1)


######### Exclude columns with only one unique values

# Columns with unique values
col_uval = sapply(loan_1, function(x) length(unique(x)))

# Count columns with only one unqiue value
cat("Count of column with one unqiue value:", length(col_uval[col_uval==1]))

# Exclude such columns with only one unique values as these will not contribute to analysis
names(col_uval[col_uval==1])
loan_1 = loan_1[, !names(loan_1) %in% names(col_uval[col_uval==1])]
dim(loan_1)

# 39717    51

######### Change Class

loan_1$int_rate=as.numeric(sub("%","",loan_1$int_rate))     # Remove % and convert to numeric
loan_1$revol_util=as.numeric(sub("%","",loan_1$revol_util)) # Remove % and convert to numeric

# histogram of interest rate:

hist(loan_1$int_rate, breaks = 50)

######### Look for Duplicate Member IDs

nrow(loan_1)                              # 39717
length(unique(loan_1$member_id))          # 39717

# duplicated(loan_1$member_id)            returns boolean values


######### Lets see type of class available in loan dataset and standardize them, if required

View(loan_1)
class=sapply(loan_1, class)
table(class)

# Observation: 
# There are 19 columns of factor class
# There are 16 columns of integer class
# There are 16 columns of numeric class

# Populate columns by type into separate variables
class.character=names(class)[class=="character"]
class.factor=names(class)[class=="factor"]
class.numeric=names(class)[class=="numeric"]
class.integer=names(class)[class=="integer"]


# Since integer is sub class of numberic, convert class integer to numeric. Also convert factor to character
loan_1[, c(class.integer)] <- as.numeric(unlist(loan_1[, c(class.integer)]))
loan_1[, c(class.factor)] <- as.character(unlist(loan_1[, c(class.factor)]))
class=sapply(loan_1, class)
table(class)

# Observation: 
# There are 19 columns of character class
# There are 32 columns of numeric class


######### Let us see the missing values

sapply(loan_1, function(x) sum(is.na(x)))

# Observation: column "title", mths_since_last_delinq", "mths_since_last_record", collections_12_mths_ex_med", "chargeoff_within_12_mths", "pub_rec_bankruptcies", "tax_liens" and "revol_util" have missing values

# Replace NA
class.character=names(class)[class=="character"]
class.numeric=names(class)[class=="numeric"]
loan_1[,c(class.numeric)][is.na(loan_1[,c(class.numeric)])] <- -999999         # assign high negative number where value in numeric field is blank,if any
loan_1[, c(class.character)][is.na(loan_1[, c(class.character)])] <- "NoData"  # assign "No Data" where value in character field is blank, if any


######### Convert Character to Factor Variables

class=sapply(loan_1, class)
table(class)

# Identify fields those needs to be retained character and others as factor
data_character<- c("id","emp_title","issue_d","url","desc","title","zip_code","addr_state","earliest_cr_line","last_pymnt_d","next_pymnt_d","last_credit_pull_d")
class.character<-setdiff(class.character,data_character)            # Create set of fields those needs to be converted to factor

# another way : class.character[is.na(match(class.character,data_character))]


# Use lapply to apply factor class on required fields
loan_1[,class.character] <- lapply(loan_1[,class.character] , factor)
str(loan_1[,c(class.character)])

# Observation: 39717 obs. of  8 variables are factors



# emp_length
table(loan_1$emp_length)
loan_1$emp_length = factor(loan_1$emp_length,levels(loan_1$emp_length)[c(1,2,4,5,6,7,8,9,10,11,3,12)])      # Categorical to Ordinal
table(loan_1$emp_length)

# Plot frequencies 
barplot(table(loan_1$emp_length))
# or using ggplot
ggplot(loan_1, aes(emp_length)) + geom_bar() # + theme_bw()


# plot home_ownership as percent of total
table(loan_1$home_ownership)
barplot(prop.table(table(loan_1$home_ownership)))

# verification_status
table(loan_1$verification_status)
#  in percentage terms ...
round(100 * prop.table(table(loan_1$verification_status)), 1)
barplot(prop.table(table(loan_1$verification_status)))

# Observation:  income was not verified for ~42% of applicant and income was either verified or source verified for ~55%


# Observation: loan term for 36 months has most defaulters compared to loan term with 60 months
# Loan Defaulters for 36 months loan term = 3227
# Loan Defaulters for 60 months loan term = 2400
table(loan_1$term,loan_1$loan_status)


###### Derive columns 

# derive dti bucket
# as per industry standards, dti of <= 0.43 is considered as good for loan issuance
# Assuming dti value is in percent
loan_with_derived_variable <-  mutate(loan_1, dti_band =ifelse(dti <= 4.3, "Less Risk", "High Risk"))


######### Derive date for issue date, earliest credit date 

head(loan_with_derived_variable[,c("issue_d","earliest_cr_line","last_credit_pull_d")])


# Since date format is mmm-yy, append start date of the month, for example "DEC-65" to "01-DEC-1965"
library(lubridate)
earl_cr_line <- dmy(paste("01-", loan_with_derived_variable$earliest_cr_line, sep=""))
issue_dt <- dmy(paste("01-", loan_with_derived_variable$issue_d, sep=""))
last_credit_pull_dt <- dmy(paste("01-", loan_with_derived_variable$last_credit_pull_d, sep=""))
past <- function(x) ifelse(x > Sys.Date(), seq(from=x, length=2, by="-100 year")[2], x)

# derive date from Earliest credit line
loan_with_derived_variable$early_cr_date = as.Date(sapply(earl_cr_line, past), "1970-01-01")

# derive date from column issue_d
loan_with_derived_variable$issue_date = as.Date(sapply(issue_dt, past), "1970-01-01")

# derive date from column last_credit_pull_d
loan_with_derived_variable$last_cr_pull_date = as.Date(sapply(last_credit_pull_dt, past), "1970-01-01")


######### Extract year and month

loan_with_derived_variable$issue_mon =str_split_fixed(as.Date(sapply(issue_dt, past), "1970-01-01"), "-", 3)[,2] # Extract Month
loan_with_derived_variable$issue_yr  =str_split_fixed(as.Date(sapply(issue_dt, past), "1970-01-01"), "-", 3)[,1] # Extract Year

loan_with_derived_variable$earl_cr_mon  =str_split_fixed(as.Date(sapply(earl_cr_line, past), "1970-01-01"), "-", 3)[,2] # Extract Month
loan_with_derived_variable$earl_cr_yr   =str_split_fixed(as.Date(sapply(earl_cr_line, past), "1970-01-01"), "-", 3)[,1] # Extract Year

loan_with_derived_variable$last_creditp_mon =str_split_fixed(as.Date(sapply(last_credit_pull_dt, past), "1970-01-01"), "-", 3)[,2] # Extract Month
loan_with_derived_variable$last_creditp_yr  =str_split_fixed(as.Date(sapply(last_credit_pull_dt, past), "1970-01-01"), "-", 3)[,1] # Extract Year


# add issue quarter, yearmonth (to calculate credit history)
loan_with_derived_variable = mutate(loan_with_derived_variable ,
                                    # paste0(as.numeric(issue_yr), "-", as.numeric(issue_mon))
                                    earl_cr_yr_mon = as.numeric(earl_cr_yr) * 100 + as.numeric(earl_cr_mon),
                                    issue_yr_mon = as.numeric(issue_yr) * 100 + as.numeric(issue_mon),
                                    issue_qtr = ceiling(as.numeric(issue_mon) / 3),
                                    issue_yr_qtr = paste0(as.numeric(issue_yr), "-Q", issue_qtr)
                                    )


# assign numeric values to sub grade 
sub_grade_vec = unique(loan_with_derived_variable$sub_grade) %>% .[order(., decreasing = T)]
loan_with_derived_variable = mutate(loan_with_derived_variable, sub_grade_score = match(loan_with_derived_variable$sub_grade, sub_grade_vec))


# reduce the number of categories of home ownership type
loan_with_derived_variable = mutate(loan_with_derived_variable, home_ownership_new = ifelse(home_ownership == "OTHER" | home_ownership == "NONE", "OTHER", 
                                                                                  ifelse(home_ownership == "MORTGAGE", "MORTGAGE",
                                                                                        ifelse(home_ownership == "RENT", "RENT", 
                                                                                                ifelse(home_ownership=="OWN","OWN",home_ownership)))))

# reduce the number of categories of purpose
loan_with_derived_variable = mutate(loan_with_derived_variable, purpose_type = ifelse(purpose == "credit_card" | purpose == "debt_consolidation", "debt",
                                                                                    ifelse(purpose == "car" | purpose == "major_purchase" | purpose == "vacation" | purpose == "wedding" | purpose == "medical" | purpose == "other" | purpose == "house" | purpose == "home_improvement" | purpose == "moving" | purpose == "renewable_energy" | purpose == "educational" | purpose == "small_business", "purchase", purpose)))


# add a feature credit_yr corresponding to the credit history of a borrower in terms of number of years:
loan_with_derived_variable = mutate(loan_with_derived_variable, 
                                      credit_yr = round(((floor(loan_with_derived_variable$issue_yr_mon/100)*100 + 
                                                            ((loan_with_derived_variable$issue_yr_mon - floor(loan_with_derived_variable$issue_yr_mon/100)*100)-1)/12*100)
                                                         - 
                                                           (floor(loan_with_derived_variable$earl_cr_yr_mon/100)*100 + 
                                                              ((loan_with_derived_variable$earl_cr_yr_mon - floor(loan_with_derived_variable$earl_cr_yr_mon/100)*100)-1)/12*100)  )/100,1))


# delinq_2yrs buckets:
loan_with_derived_variable = mutate(loan_with_derived_variable, delinq_bucket = ifelse(loan_with_derived_variable$delinq_2yrs > 2, "2+", delinq_2yrs))


# inq_last_6mths buckets:
loan_with_derived_variable = mutate(loan_with_derived_variable, inq_bucket = ifelse(inq_last_6mths >= 7, "7+", 
                                    ifelse(inq_last_6mths >= 5, "5-6", 
                                           ifelse(inq_last_6mths >= 3, "3-4", 
                                                  ifelse(inq_last_6mths >= 1, "1-2", 0)))))


# Annual income quantile buckets:
income_qtl = quantile(loan_with_derived_variable$annual_inc, seq(0,1,0.1))
label = c(0, income_qtl[2:10], "+inf")
income_label = paste(label[1:10], label[2:11], sep = "-")
loan_with_derived_variable = mutate(loan_with_derived_variable, annual_inc_bucket = cut(loan_with_derived_variable$annual_inc, breaks = income_qtl, labels = factor(income_label), include.lowest=TRUE))



# DTI quantile buckets:
dti_qtl = quantile(loan_with_derived_variable$dti, seq(0,1,0.1))
dti_label = c(0, dti_qtl[2:10], "+inf")
dti_labels = paste(dti_label[1:10], dti_label[2:11], sep = "-")
loan_with_derived_variable = mutate(loan_with_derived_variable, dti_bucket = cut(loan_with_derived_variable$dti, breaks = dti_qtl, labels = factor(dti_labels), include.lowest=TRUE))


# Revolving balance quantile buckets:
rev_bal_qtl = quantile(loan_with_derived_variable$revol_bal, seq(0,1,0.1))
rev_bal_label = c(0, rev_bal_qtl[2:10], "+inf")
rev_bal_labels = paste(rev_bal_label[1:10], rev_bal_label[2:11], sep = "-")
loan_with_derived_variable = mutate(loan_with_derived_variable, revol_bal_bucket = cut(loan_with_derived_variable$revol_bal, breaks = rev_bal_qtl, labels = factor(rev_bal_labels), include.lowest=TRUE))


# credit_yr quantile buckets:
credit_qtl = quantile(loan_with_derived_variable$credit_yr, seq(0,1,0.1))
credit_label = c(0, credit_qtl[2:10], "+inf")
credit_labels = paste(credit_label[1:10], credit_label[2:11], sep = "-")
loan_with_derived_variable = mutate(loan_with_derived_variable, credit_yr_bucket = cut(loan_with_derived_variable$credit_yr, breaks = credit_qtl, labels = factor(credit_labels), include.lowest=TRUE))


# derive income range of loan defaulters
loan_with_derived_variable <- mutate(loan_with_derived_variable, incomerange = ifelse(annual_inc == 0, "0",
                                                                ifelse(annual_inc > 0 & annual_inc < 4000,"0 - 4000",
                                                                       ifelse(annual_inc >= 4000 & annual_inc <= 50000,"4000 - 50000",
                                                                              ifelse(annual_inc > 50000 & annual_inc <= 100000,"50001 - 100000",
                                                                                     ifelse(annual_inc > 100000 & annual_inc <= 150000, "100001 - 150000",
                                                                                            ifelse(annual_inc > 150000 & annual_inc <= 200000,"150001 - 200000",
                                                                                                   ifelse(annual_inc > 200000 & annual_inc <= 250000, "200001 - 250000",
                                                                                                          ifelse(annual_inc > 250000 & annual_inc <= 300000, "250001 - 300000",
                                                                                                                 ifelse(annual_inc > 300000 & annual_inc <= 350000, "300001 - 350000",
                                                                                                                        ifelse(annual_inc > 350000 & annual_inc <= 400000, "350001 - 400000",
                                                                                                                               ifelse(annual_inc > 400000 & annual_inc <= 450000, "400001 - 450000",
                                                                                                                                      ifelse(annual_inc > 450000 & annual_inc <= 500000, "450000 - 500000",
                                                                                                                                             ifelse(annual_inc > 500000 & annual_inc <= 550000, "500001 - 550000",
                                                                                                                                                    ifelse(annual_inc > 550000 & annual_inc <= 600000, "550001 - 600000",
                                                                                                                                                           ifelse(annual_inc >600000 & annual_inc <=650000, "600001 - 650000",
                                                                                                                                                                  ifelse(annual_inc > 650000 & annual_inc <=700000, "650001 - 700000",
                                                                                                                                                                         ifelse(annual_inc > 700000 & annual_inc <=750000, "700001 - 750000",
                                                                                                                                                                                ifelse(annual_inc > 750000 & annual_inc <= 800000, "750001 - 800000",
                                                                                                                                                                                       ifelse(annual_inc >800000 & annual_inc <=850000,"800001 - 850000",
                                                                                                                                                                                              ifelse(annual_inc >850000 & annual_inc<=900000,"850001 - 900000",
                                                                                                                                                                                                     ifelse(annual_inc >900000 & annual_inc<=950000,"900001 - 950000",
                                                                                                                                                                                                            ifelse(annual_inc > 950000 & annual_inc <= 1000000, "950001 - 1000000",
                                                                                                                                                                                                                   ifelse(annual_inc > 1000000 & annual_inc <= 1500000, "1000001 - 1500000","greater than 1500000"))))))))))))))))))))))))


################### Exploratory Data Analysis on overall loan data begins ##########################


# let's plot loan issuance by year 
ggplot(loan_with_derived_variable) + geom_bar(aes(issue_yr)) 

# let's plot loan issuance by quarter 
ggplot(loan_with_derived_variable) + geom_bar(aes(issue_yr_qtr)) 

# let's plot by month to check the number of loans that have been issued
ggplot(loan_with_derived_variable) + geom_bar(aes(issue_mon)) 


# Report showing the amounts and number of loans in each category- status of the loans

loanvalue_status=loan_with_derived_variable %>% 
                 group_by(loan_status) %>%
                  summarise(.,  total_issued_in_mill = round(sum(loan_amnt/1e6),1),                    # issued amount (in millions)
                                n = round(n()))



# Report showing the amounts and number of loans in each category- grade
loanvalue_grade=loan_with_derived_variable %>% 
                  group_by(grade) %>%
                  summarise(., total_issued = round(sum(loan_amnt/1e6),1),
                            n = round(n()))


# Report on charge off rate by grade
charge_rate_grade=loan_with_derived_variable %>% 
  group_by(grade) %>%
  summarise(., charged   = round(sum(loan_status == "Charged Off") / n() * 100, 2))


####### Now we will take each features available during the debt and attempt to extract their relation to default rates ###

# Home ownership: Do Home ownership have any relationship with charge off ?

# Report on loan amount by home ownership
loanvalue_home =loan_with_derived_variable %>% 
                    group_by(home_ownership_new) %>%
                    summarise(., total_issued = round(sum(loan_amnt/1e6),1),
                              n = round(n()))



# Report on charge off rate by home ownership
charge_rate_home=loan_with_derived_variable %>% 
                    group_by(home_ownership_new) %>%
                    summarise(., charged   = round(sum(loan_status == "Charged Off") / n() * 100, 2))




# combine the dataset - loanvalue_home and charge_rate_home
X <- cbind(loanvalue_home,charge_rate_home)
combined_home_dt <-X[,c(1:3,5)]
str(combined_dt)


 
 p <- ggplot(data = combined_home_dt, aes(x = home_ownership_new, y = total_issued , fill = charged ))
 p + geom_bar(stat = "identity", width = 0.5, position = "dodge") +
   geom_text( aes(label = total_issued, vjust = -.5)) +
   labs(title="Plot on home ownership and charge off rate",x="Home Ownership",y="Issued loan amount (in million)") 
   # theme(axis.text.x=element_text(angle=90, hjust=1))

 

# Observation: The issuance of loan amount is highest in case where Home ownership type is MORTGAGE (~224 million) followed by RENT (~189 million)are risky
# as the charge off rate in case where Home ownership is RENT (~15%) followed by MORTGAGE (~13%)


# Purpose: Do loan purpose have any relationship with charge off ? 

# Report on loan amount by purpose
loanvalue_purpose =loan_with_derived_variable %>% 
                    group_by(purpose) %>%
                    summarise(., total_issued = round(sum(loan_amnt/1e6),1),
                              n = round(n())) 



# Report on charge off rate by purpose
charge_rate_purpose =loan_with_derived_variable %>% 
                      group_by(purpose) %>%
                      summarise(., charged   = round(sum(loan_status == "Charged Off") / n() * 100, 2))




# combine the dataset - loanvalue_purpose and charge_rate_purpose
Y <- cbind(loanvalue_purpose,charge_rate_purpose)
combined_purpose_dt <-Y[,c(1:3,5)]
str(combined_purpose_dt)


q <- ggplot(data = combined_purpose_dt, aes(x = purpose, y = total_issued , fill = charged ))
q + geom_bar(stat = "identity", width = 0.5, position = "dodge") +
    geom_text( aes(label = total_issued, vjust = -.5)) +
    labs(title="Plot on loan purpose and charge off rate",x="Loan Purpose",y="Issued loan amount (in million)") +
   theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: The loan taken for purpose of small business (~25 million) and education (~2 million) are risky 
#               as the charge of rate is highest where purpose is small business (~26%) followed by education (~17%)




# DTI (Debt To Income ratio): Do dti have any relationship with charge off ?

# Report on loan amount by purpose
loanvalue_dti =loan_with_derived_variable %>% 
  group_by(dti_bucket) %>%
  summarise(., total_issued = round(sum(loan_amnt/1e6),1),
            n = round(n())) 



# Report on charge off rate by purpose
charge_rate_dti =loan_with_derived_variable %>% 
  group_by(dti_bucket) %>%
  summarise(., charged   = round(sum(loan_status == "Charged Off") / n() * 100, 2))


# combine the dataset - loanvalue_home and charge_rate_home
Z <- cbind(loanvalue_dti,charge_rate_dti)
combined_dti_dt <-Z[,c(1:3,5)]
str(combined_dti_dt)

r <- ggplot(data = combined_dti_dt, aes(x = dti_bucket, y = total_issued , fill = charged ))
r + geom_bar(stat = "identity", width = 0.5, position = "dodge") +
  geom_text( aes(label = total_issued, vjust = -.5)) +
  labs(title="Plot on dti and charge off rate",x=" DTI bucket",y=" Issued loan amount (in million)") 



# Bar plot on loan status
loan_status_value<-ggplot(loan_with_derived_variable, aes(x = factor(loan_status), fill=loan_status))
loan_status_value +
  geom_bar(stat = "count",position = "dodge") +      # ,width = 0.5
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.15) +
  labs(title = "Report on loan status",  x = "Loan status",y = "Count") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Bar plot to analyze purpose of loan availed by loan defaulters
borr_purpose<-ggplot(loan_with_derived_variable, aes(x = factor(purpose), fill=purpose))

borr_purpose +
  geom_bar(stat = "count") +      # ,width = 0.5 ,position = "dodge"
  geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) + #vjust = -0.15
  labs(title = "Loan purpose",  x = "Loan Purpose", y = "Count") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: From the plot ~59% of loan are for debt refinancing

# Bar plot to analyze dti of loan defaulters 
borr_dti_bucket<-ggplot(loan_with_derived_variable, aes(x = factor(dti_bucket), fill=dti_bucket))

borr_dti_bucket +
  geom_bar(stat = "count", width = 0.25) +      #  ,position = "dodge"
  geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) + #vjust = -0.15
  labs(title = "dti of loan defaulters", y = "Count", x = "Debt to Income Ratio Band") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: 99% of borrowers have high dti ratio which qualifies as bad loan

# Analyze loan amount of the borrwers
qplot(x = loan_amnt, data = loan_with_derived_variable,
      binwidth = 1000, colour = I("#424242"), fill = I("#0077C0")) +
  scale_x_continuous(breaks = seq(0, 35000, 5000))


# Bar plot on grade with loan status
borrower_grade<-ggplot(loan_with_derived_variable, aes(x = factor(grade), fill=grade))
borrower_grade +
  geom_bar(stat = "count",position = "dodge", width = 0.4) +     
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count" , position = position_stack(vjust = 0.5)) + 
  labs(title = "Report on graded borrowers",  x = "Borrower Grade",y = "Count")

 
#################### Plot - Univariate Segmented analysis ##################################


# Distribution by loan status and verification_status
loan_sts<-ggplot(loan_with_derived_variable, aes(x = factor(loan_status), fill=verification_status))
loan_sts +
  geom_bar(stat = "count",width = 0.3) +      
  # geom_text(aes(label=incomerange_count),  stat = "count", vjust = -0.15) +
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count",  position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan status and verification status", y = "Count", x = "Loan Status") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# legend("topright", legend=c("Ixos","Primadur"), col=c(rgb(1,0,0,0.5), rgb(0,0,1,0.5)), pt.cex=2, pch=15 )

# Observation: From loan dataset, 14.2% of customers are defaulters while 83% of customers have repaid the loan and ~3% currently paying
# While there are 36.6% non verified loan which were repaid, 5.4% non verified loan were charged off 


# Distribution by loan status and dti
loan_sts_dti<-ggplot(loan_with_derived_variable, aes(x = factor(loan_status), fill=dti_bucket))
loan_sts_dti +
  geom_bar(stat = "count",width = 0.3) +      
  # geom_text(aes(label=incomerange_count),  stat = "count", vjust = -0.15) +
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count",  position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan status and dti", y = "Count", x = "Loan Status")
  

# Distribution by loan status and term
loan_sts_term<-ggplot(loan_with_derived_variable, aes(x = factor(loan_status), fill=term))
loan_sts_term +
  geom_bar(stat = "count",width = 0.3) +      
  # geom_text(aes(label=incomerange_count),  stat = "count", vjust = -0.15) +
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count",  position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan status and term", y = "Count", x = "Loan Status")

# Observation: Most loan are 36 months, out of which majority (65%) are repaid and 8.1% are charged off


# Distribution by loan purpose and loan status
loan_purpose<-ggplot(loan_with_derived_variable, aes(x = factor(purpose), fill=loan_status))
loan_purpose +
  geom_bar(stat = "count",width = 0.75) +  
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan purpose and loan status", y = "Count", x = "Loan Purpose") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: Except for loan where purpose is renewable energy, all other loans with various purpose have defaulters
# Defaulters with loan purpose as "debt_consolidation" are maximum followed by loan with purpose as credit_card, other and small_business



# Distribution by loan purpose (derived) and loan status
loan_purpose_new<-ggplot(loan_with_derived_variable, aes(x = factor(purpose_new), fill=loan_status))
loan_purpose_new +
  geom_bar(stat = "count",width = 0.75) +  
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by merged  loan purpose and loan status", y = "Count", x = "Loan Purpose") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Distribution by home_ownership and loan status
loan_sts_home_ownership<-ggplot(loan_with_derived_variable, aes(x = factor(home_ownership), fill=loan_status))
loan_sts_home_ownership +
  geom_bar(stat = "count",width = 0.5) +  
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan status and home ownership", y = "Count", x = "Home Ownership") +
  theme(axis.text.x=element_text(angle=90, hjust=1))

# Observation: There are ~7% of defaulted loan by borrower who stay on rent, ~6% of defaulted loan by borrowers with mortgaged home




# Distribution by merged home ownership and loan status
loan_sts_home<-ggplot(loan_with_derived_variable, aes(x = factor(home), fill=loan_status))
loan_sts_home +
  geom_bar(stat = "count",width = 0.5) +  
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Distribution by loan status and merged home ownership", y = "Count", x = "Home Ownership") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Bar plot on grade with loan status
loan_status_grade<-ggplot(loan_with_derived_variable, aes(x = factor(grade), fill=loan_status))
loan_status_grade +
  geom_bar(stat = "count",position = "dodge") +      # ,width = 0.5
  geom_text( aes(label = scales::percent((..count..)/sum(..count..))), stat = "count") +     # , position = position_stack(vjust = 0.5)
  labs(title = "Report on grade with loan status",  x = "Loan status",y = "Count")


######################### Lets analyze loan defaulters who had borrowed for debt consolidation ##########################################

######################### EDA - Univariat Segment analysis ########################

ld_with_purpose_debt_consol <- loan_defaulter_1[loan_defaulter_1$purpose=="debt_consolidation",]


# plot verification status of loan defaulters who had borrowed for debt consolidation 
borr_verification<-ggplot(ld_with_purpose_debt_consol, aes(x = factor(incomerange), fill=verification_status))
borr_verification +
  geom_bar(stat = "count") +      # ,width = 0.5
  geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Income Range of loan defaulters who availed loan for debt consolidation", y = "Count", x = "Income Range") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Observation from bar plot
# Among the loan defaulters with loan purpose as debt consolidation and 
  # are in income range of 4000 and 50000, 
    # ~ 19% of defaulters were sanctioned loan without verification 
    # ~ 14% of defaulters were sanctioned loan with verification but they still defaulted; why? has verification really happened ?
  # are in income range of 50001 and 100000, 
    # ~ 13% of defaulters were sanctioned loan without verification
    # ~ 23% of defaulters were sanctioned loan with verification but they still defaulted; why? has verification really happened ?


# plot emp tenure of loan defaulters who had borrowed for debt consolidation 
borr_emp_tenure<-ggplot(ld_with_purpose_debt_consol, aes(x = factor(incomerange), fill=emp_length))
borr_emp_tenure +
  geom_bar(stat = "count") +      # ,width = 0.5
  geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "Income Range of loan defaulters with purpose as debt consolidation", y = "Count", x = "Income Range") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Observation from bar plot
# Among the loan defaulters with loan purpose as debt consolidation and 
  # are in income range of 4000 and 50000,
    # 7.2% borrowers are with 10+ years of experience
    # 6.2% borrowers are with less then one year of experience
    # 5.5% borrowers are with 2 years of experience
  # are in income range of 50001 and 100000, 
    # 15.1% borrowers are with 10+ years of experience
    # 4.6% borrowers are with 3 years of experience

summary(ld_with_purpose_debt_consol$dti)



length(dti1_$dti)

# analyze dti of loan defaulters with loan purpose as debt consolidation
borr_dti_dist<-ggplot(ld_with_purpose_debt_consol, aes(x = factor(incomerange), fill=dti_bucket))
borr_dti_dist +
  geom_bar(stat = "count") +      # ,width = 0.5
  geom_text(aes(label = scales::percent((..count..)/sum(..count..))), stat = "count", position = position_stack(vjust = 0.5)) +
  labs(title = "dti distribution of loan defaulters with purpose as debt consolidation", y = "Count", x = "Income Range") +
  theme(axis.text.x=element_text(angle=90, hjust=1))


# Observation from bar plot
# Among the loan defaulters with loan purpose as debt consolidation and 
  # are in income range of 4000 and 50000,
    # 45% of defaulters have high debt to income ratio
  # are in income range of 50001 and 100000,
    # 45% of defaulters have high debt to income ratio


